export interface Product{
    
}