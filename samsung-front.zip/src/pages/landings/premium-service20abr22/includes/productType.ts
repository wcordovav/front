export interface Product {
    company?: string;
    div?: string;
    category: string;
    name: string;
    model?: string;
    imagen: string;
    url: string;
}