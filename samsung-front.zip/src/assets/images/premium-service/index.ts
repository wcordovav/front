import slider1 from "./slider_tv_desktop.jpg";
import slider1_mobile from "./slider_tv_mobile.jpg";
import slider2 from "./slider_lavadora_desktop.jpg";
import slider2_mobile from "./slider_lavadora_mobile.jpg";
import slider3 from "./slider_refrigeradora_desktop.jpg";
import slider3_mobile from "./slider_refrigeradora_mobile.jpg";
import slider4 from "./slider_cocina_desktop.jpg";
import slider4_mobile from "./slider_cocina_mobile.jpg";

export {
    slider1,
    slider1_mobile,
    slider2,
    slider2_mobile,
    slider3,
    slider3_mobile,
    slider4,
    slider4_mobile
}